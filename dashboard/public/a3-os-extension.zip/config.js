globalThis.A3OS_CONFIG = {
    SUPABASE_URL: "https://kvvcbkamxalcklnyodeu.supabase.co",
    SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt2dmNia2FteGFsY2tsbnlvZGV1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODc1Mjg3MTMsImV4cCI6MjEwMzEwNDcxM30.jdC8kr8qzUVxCkyE1SvkFpgDDby_NROpCisJ2fknUrg"
};
